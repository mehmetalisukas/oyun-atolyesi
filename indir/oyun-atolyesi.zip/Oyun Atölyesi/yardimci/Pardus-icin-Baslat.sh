#!/bin/bash
# Oyun Atölyesi'ni başlatır (Pardus / Linux).
cd "$(dirname "$(readlink -f "$0")")/.." || exit 1
chmod +x yardimci/sunucu-linux-amd64 2>/dev/null
exec ./yardimci/sunucu-linux-amd64 "$PWD"
