#!/bin/bash
# Oyun Atölyesi'ni başlatır (Mac). İlk seferde bu dosyaya sağ tıklayıp "Aç" deyin.
cd "$(dirname "$0")/.." || exit 1
xattr -dr com.apple.quarantine . 2>/dev/null
A=$(uname -m); [ "$A" = "arm64" ] || A=amd64
chmod +x "yardimci/sunucu-mac-$A" 2>/dev/null
echo ""
echo "  Oyun Atölyesi açılıyor..."
echo "  Bu pencereyi kapatmayın. İşiniz bitince uygulamadaki Çıkış düğmesine basın."
echo ""
exec "./yardimci/sunucu-mac-$A" "$PWD"
